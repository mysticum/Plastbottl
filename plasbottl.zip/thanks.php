<?php
  include('parts/header.php');
?>

<div class="wraper">
  <section id="promo">
    <h1>Спасибо!</h1><br>
    <p>Мы свяжемся с вами близжайшее время.</p>
  </section>
</div>

<?php
    include("parts/footer_f.php")
?>